document.addEventListener('DOMContentLoaded', () => {
  console.log("SMS Reminders page loaded – Preview mode");
});

